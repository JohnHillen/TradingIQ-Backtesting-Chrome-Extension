const page = {}

page.waitForTimeout = async (timeout = 2500) => new Promise(resolve => setTimeout(resolve, timeout))

page.waitForSelectorOld2del = async function (selector, timeout = 5000, isHide = false, parentEl) { //2023-04-18
  parentEl = parentEl ? parentEl : document
  return new Promise(async (resolve) => {
    let iter = 0
    let elem
    const tikTime = timeout === 0 ? 1000 : 50
    do {
      await page.waitForTimeout(tikTime)
      elem = parentEl.querySelector(selector)
      iter += 1
    } while ((timeout === 0 ? true : (tikTime * iter) < timeout) && (isHide ? !!elem : !elem))
    resolve(elem)
  });
}

page.waitForSelectorInnerText = async (selector, timeout = 5000, isHide = false, parentEl = null) => {
  let el = await waitForSelector(selector, timeout, isHide, parentEl, false)
  return el ? el.innerText : null
}

page.waitForSelector = async (selector, timeout = 5000, isHide = false, parentEl = null) => {
  return waitForSelector(selector, timeout, isHide, parentEl, false)
}

page.waitForSelectorAll = async (selector, timeout = 5000, isHide = false, parentEl = null) => {
  return waitForSelector(selector, timeout, isHide, parentEl, true)
}

async function waitForSelector(selector, timeout = 5000, isHide = false, parentEl = null, selectorAll) {
  return new Promise(async (resolve) => {
    parentEl = parentEl ? parentEl : document
    let iter = 0
    let elem = selectorAll ? parentEl.querySelectorAll(selector) : parentEl.querySelector(selector)
    const tikTime = timeout === 0 ? 1000 : 50
    while (timeout === 0 || (!isHide && !elem) || (isHide && !!elem)) {
      await page.waitForTimeout(tikTime)
      elem = selectorAll ? parentEl.querySelectorAll(selector) : parentEl.querySelector(selector)
      iter += 1
      if (elem || (timeout !== 0 && tikTime * iter >= timeout))
        break
    }
    return resolve(elem ? elem : null)
  })
}

const reactValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
page._inputEvent = new Event('input', { bubbles: true });
page._changeEvent = new Event('change', { bubbles: true });

page._mouseEvents = {};
["mouseover", "mousedown", "mouseup", "click",
  "dblclick", "contextmenu"].forEach(eventType => {
    page._mouseEvents[eventType] = document.createEvent('MouseEvents')
    page._mouseEvents[eventType].initEvent(eventType, true, true)
  })

page.getTextForSel = function (selector, elParent) {
  elParent = elParent ? elParent : document
  const element = elParent.querySelector(selector)
  return element ? element.innerText : null
}

page.setInputElementValue = function (element, value, isChange = false) {
  reactValueSetter.call(element, value)
  element.dispatchEvent(page._inputEvent);
  if (isChange) element.dispatchEvent(page._changeEvent);
}

page.typeIntoInput = async function (input, text) {
  let l = text.length
  let current = 0
  input.focus()
  input.value = ''

  while (current < l - 1) {
    console.log('typeIntoInput:', text[current], 'timestamp:', new Date().getTime())
    input.value += text[current]
    current++
    input.dispatchEvent(page._changeEvent)
    await page.waitForTimeout(util.getRandomInt(45, 20))
  }
}

page.mouseClick = function (el) {
  ["mouseover", "mousedown", "mouseup", "click"].forEach((eventType) => {
    let event = new MouseEvent(eventType, {
      'view': window,
      'bubbles': true,
      'cancelable': true
    });
    el.dispatchEvent(event)
  }
  )
}

page.mouseClickSelector = function (selector) {
  const el = document.querySelector(selector)
  if (el)
    page.mouseClick(el)
}

page.waitForMouseClickSelector = async function (selector, timeout = 1000) {
  const el = await page.waitForSelector(selector, timeout)
  if (el) {
    page.mouseClick(el)
    await page.waitForTimeout(50)
  }
}

page.pressTab = function (el) {
  page.pressKey(el, 'Tab', 9)
}

page.pressKey = function (el, key, keyCode) {
  ["keydown", "keypress", "keyup"].forEach((eventType) => {
    let event = new KeyboardEvent('keydown', {
      key: key,
      code: key,
      keyCode: keyCode,
      which: keyCode,
      bubbles: true,
      cancelable: true
    });
    el.dispatchEvent(event)
  })
}

page.$ = function (selector) {
  return document.querySelector(selector)
}

page.getElText = (element) => {
  return element.innerText.replaceAll('​', '')
}

page.setSelByText = (selector, textValue) => {
  let isSet = false
  const selectorAllVal = document.querySelectorAll(selector)
  if (!selectorAllVal || !selectorAllVal.length)
    return isSet
  for (let optionsEl of selectorAllVal) {
    if (optionsEl) {//&& options.innerText.startsWith(textValue)) {
      const itemValue = page.getElText(optionsEl).toLowerCase()
      if (itemValue && textValue && itemValue.startsWith(textValue.toLowerCase())) {
        page.mouseClick(optionsEl)
        isSet = true
        break
      }
    }
  }
  return isSet
}

page.triggerTrustedClick = (element) => {
  // 1. Finde die exakte Mitte des Elements
  const rect = element.getBoundingClientRect();
  const clickX = Math.round(rect.left + rect.width / 2);
  const clickY = Math.round(rect.top + rect.height / 2);

  console.log(`Sende "Trusted Click" Befehl an x:${clickX}, y:${clickY}`);

  // 2. Sende die Koordinaten an das Background-Skript
  chrome.runtime.sendMessage({
    action: "performTrustedClick",
    x: clickX,
    y: clickY
  }, (response) => {
    if (response && response.success) {
      console.log('Debugger Klick erfolgreich ausgeführt!');
    } else {
      console.error('Debugger Klick fehlgeschlagen:', response.error);
    }
  });
}

